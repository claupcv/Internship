﻿CREATE TABLE [dbo].[Table]
(
	[Id_student] INT NOT NULL PRIMARY KEY, 
    [name] VARCHAR(50) NOT NULL, 
    [surname] VARCHAR(50) NOT NULL, 
    [sex] SMALLINT NOT NULL, 
    [date_of_registration] DATE NOT NULL
)
