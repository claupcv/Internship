﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqExcercises
{
    public class University
    {

        private static int countUniversityID;

        public int UniversityID { get; set; } = 0;

        public string UniversityName { get; set; } = "";

        public string Address { get; set; } = "";

        public University(int universityID, string universityName, string address)
        {
            if (string.IsNullOrEmpty(universityName) || string.IsNullOrEmpty(address))
            {
                this.UniversityID = University.countUniversityID + 1;
                this.UniversityName = universityName;
                this.Address = address;

                University.countUniversityID++;
            }
            else
            {
                Console.WriteLine($"Check {this.GetType().Name} input values please");
            }
        }

        public University()
            : this(0, "", "")
        {
            Console.WriteLine($"Check {this.GetType().Name} input values please");
        }
    }
}
