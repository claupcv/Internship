﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqExcercises
{
    public class Student : Person
    {
        public List<int> UniversityID = new List<int>();

        public Student(string firstName, string lastName, int age, DateTime birthDay, int universityID)
            :base(firstName, lastName, age, birthDay)
        {
            UniversityID.Add(universityID);
        }

        public Student()
            : base()
        { }
    }
}
