﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqExcercises
{
    public class Person
    {
        private static int countCourseID;

        public int PersonID { get; private set; } = 0;

        public string FirstName { get; private set; } = "";

        public string LastName { get; private set; } = "";

        public int Age { get; private set; } = 0;

        public DateTime BirthDay { get; private set; } = DateTime.MinValue;

        public Person(string firstName, string lastName, int age, DateTime birthDay)
        {
            if (!string.IsNullOrEmpty(firstName + lastName) || age > 0 || birthDay != null)
            {
                this.PersonID = Person.countCourseID + 1;
                this.FirstName = firstName;
                this.LastName = lastName;
                this.Age = age;
                this.BirthDay = birthDay;
                Person.countCourseID++;
            }

            else
            {
                Console.WriteLine($"Check {this.GetType().Name} input values please");
            }
        }

        public Person()
            : this("", "", 0, DateTime.MinValue)
        {

        }

    }
}
