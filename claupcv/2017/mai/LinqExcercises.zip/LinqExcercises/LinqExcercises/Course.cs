﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqExcercises
{
	public class Course
	{
        private static int countCourseID;

        public int CourseID { get; set; } = 0;

		public int UniversityID { get; set; } = 0;

		public string CourseName { get; set; } = "";

		public int CourseYear { get; set; } = 0;

		public int CourseSemester { get; set; } = 0;

        public Course(int courseID, University university, string courseName, int courseYear, int courseSemester)
        {
            if (university!=null && university.UniversityID > 0
                || (!string.IsNullOrEmpty(courseName))
                || courseYear > 0
                || courseSemester>0 )
            {
                this.CourseID = Course.countCourseID;
                this.UniversityID = university.UniversityID;
                this.CourseName = courseName;
                this.CourseYear = courseYear;
                this.CourseSemester = courseSemester;

                Course.countCourseID++;
            }
            else
            {
                Console.WriteLine($"Check {this.GetType().Name} input values please");
            }
            
        }
	}
}
