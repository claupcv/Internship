﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqExcercises
{
    public class Grade
    {
        private static int countGradeID;

        public int GradeID { get; set; } = 0;

        public int CourseID { get; set; } = 0;

        public float GradeValue { get; set; } = 0;

        public Grade(Course course, float gradeValue)
        {
            if (course != null && course.CourseID > 0
                || gradeValue>0)
            {
                this.GradeID = Grade.countGradeID + 1;
                this.CourseID = course.CourseID;
                this.GradeValue = gradeValue;

                Grade.countGradeID++;
            }
            else
            {
                Console.WriteLine($"Check {this.GetType().Name} input values please");
            }
        }
    }
}
