﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structs
{
    struct RectangleStruct
    {
        public int X, Y, Width, Height;
    }
}
