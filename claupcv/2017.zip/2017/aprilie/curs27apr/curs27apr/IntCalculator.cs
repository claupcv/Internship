﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace curs27apr
{
	public class IntCalculator
	{
		public int Sum(int a, int b)
		{
			return a + b;
		}
	}
}
